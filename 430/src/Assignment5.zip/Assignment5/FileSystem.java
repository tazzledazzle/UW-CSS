package Assignment5;

/**
 * Created by tazzledazzle on 3/3/15.
 */
public class FileSystem {
    //========================================== Attributes ==============================================
    private static final boolean FAILURE = false;
    private static final boolean SUCCESS = true;

    //superblock
    //directory
    //fileTable

    //============================================= Methods ==============================================
    public FileSystem()
    {

    }
    public void sync()
    {
        //open root directory with write access
        //write directory to root
        //close root directory
        //sync superblock
    }

    public boolean format(){
        //call format on superblock for arg number of files
        //create directory, and register "/" in directory entry 0
        //file table is created and store directory in the file table
        //return true on completion
        return true;
    }

    public FileTableEntry open(String filename, String mode){
        //allocate a new filetable entry, specifying the filename and the mode
        // check if writing mode
            // if so, make sure all blocks are unallocated
        //return FileTableEntry, not null
        return null;
    }

    public boolean close(FileTableEntry entry){
        //cast the entry as synchronized
        // decrease the number of users
        // if the entry.count is 0, free the file entry in the file table
        return true;
    }

    public int fsize(FileTableEntry entry){
        //cast the entry as synchronized
        // Set a new Inode object to the entries Inode
        // return the length on the new Inode object
        return -1;
    }

    public int read(FileTableEntry entry, byte[] buffer){
        //check write or append status
            //return error
        int size = buffer.length;   //set total size of data to read
        int rBuffer = 0;            //track data read
        int rError = -1;            //track error on read
        int blockSize = 512;        //set block size
        int itrSize = 0;            //track how much is left to read

        //cast the entry as synchronized
        //loop to read chunks of data

    }

    public int write(FileTableEntry fileTableEntry, byte[] buffer){

    }

    private boolean deallocAllBlocks(FileTableEntry fileTableEntry){
        //return if inode is null
        //handle direct pointer blocks
        //get any data from indirect ptr
        //write back inodes to disk
        return FAILURE;
    }

    public boolean delete(){
        //grab tcb file table entry
        //try to free and then delete
        //return success if complete
        //otherwise return failure
        return FAILURE;
    }

    public int seek(FileTableEntry fileTableEntry, int offset, int location){

    }
}
