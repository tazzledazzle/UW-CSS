package Assignment5;

/**
 * Created by tazzledazzle on 3/3/15.
 */
public class Directory {
    private static int maxChars = 30; // max characters of each file name
    private static int MAX_BYTES = 60;
    private static int ALLOC_BYTE = 64;
    private static int BLOCK = 4;
    private static short ERROR = -1;
    private static boolean SUCCESS = true;
    private static boolean FAILURE = false;

    // Directory entries
    private int fsize[];        // each element stores a different file size.
    private int directorySize;  // size of directory
    private char fnames[][];    // each element stores a different file name.

    public Directory( int maxInumber )
    { // directory constructor
        fsizes = new int[maxInumber];     // maxInumber = max files
        for ( int i = 0; i < maxInumber; i++ )
            fsize[i] = 0;                 // all file size initialized to 0
        directorySize = maxInumber;
        fnames = new char[maxInumber][maxChars];
        String root = "/";                // entry(inode) 0 is "/"
        fsize[0] = root.length( );        // fsize[0] is the size of "/".
        root.getChars( 0, fsizes[0], fnames[0], 0 ); // fnames[0] includes "/"
    }

    public void bytes2directory( byte data[] )
    {
        // assumes data[] received directory information from disk
        int offset = 0;
        for (int i = 0; i < directorySize; i++)
        {
            fsize[i] = SysLib.bytes2int(data, offset);
            offset += BLOCK;
        }
        // initializes the Directory instance with this data[]
        for (int i = 0; i < directorySize; i++)
        {
            String temp = new String(data, offset, MAX_BYTES);
            temp.getChars(0, fsize[i], fnames[i], 0);
            offset += MAX_BYTES;
        }
    }

    public byte[] directory2bytes( )
    {
        byte [] dir = new byte[ALLOC_BYTE * directorySize];
        int offset = 0;
        // converts and return Directory information into a plain byte array
        for (int i = 0; i < directorySize; i++)
        {
            SysLib.int2bytes(fsize[i], dir, offset);
            offset += BLOCK;
        }
        for (int i = 0; i < directorySize; i++)
        {
            String temp = new String(fnames[i], 0, fsize[i]);
            bytes [] bytes = temp.getBytes();
            System.arraycopy(bytes, 0, dir, offset, bytes.length);
            offset += MAX_BYTES;
        }
        return dir;
    }

    public short ialloc( String filename )
    {
        // filename is the one of a file to be created.
        for (short i = 0; i < directorySize; i++)
        {
            if (fsize[i] == 0)
            {
                // allocates a new inode number for this filename
                int file = filename.length() > maxChars ? maxChars : filename.length();
                fsize[i] = file;
                filename.getChars(0, fsize[i], fnames[i], 0);
                return i;
            }
        }
        return ERROR;
    }

    public boolean ifree( short iNumber )
    {
        // deallocates this inumber (inode number)
        if (iNumber < maxChars && fsize[iNumber] > 0)
        {
            fsize[iNumber] = 0;
            return SUCCESS;
        } else
        {
            return FAILURE;
        }
        // the corresponding file will be deleted.
    }

    public short namei( String filename )
    {
        for (short i = 0; i < directorySize; i++){
            if (filename.length() == fsize[i]){
                String temp = new String(fnames[i], 0, fsize[i]);
                if(filename.equals(temp)){
                    return i;
                }
            }
        }
        return ERROR;
    }

    private void printDir(){
        for (int i = 0; i < directorySize; i++){
            SysLib.cout(i + ":  " + fsize[i] + " bytes - ");
            for (int j = 0; j < maxChars; j++){
                SysLib.cout(fnames[i][j]);
            }
            SysLib.cout("\n");
        }
    }
}
