package Assignment5;

import java.util.Vector;

/**
 * Created by tazzledazzle on 3/3/15.
 */
public class FileTable {
    public final static int EMPTY = 0;
    public final static int USED = 1;
    public final static int READ = 2;
    public final static int WRITE = 3;

    private Vector<FileTableEntry> table;         // the actual entity of this file table
    private Directory dir;        // the root directory

    public FileTable( Directory directory ) { // constructor
        table = new Vector<FileTableEntry>( );     // instantiate a file (structure) table
        dir = directory;           // receive a reference to the Director
    }                             // from the file system

    // major public methods
    public synchronized FileTableEntry falloc( String filename, String mode ) {
        short iNum = -1;
        Inode inode = null;
        while (true) {
            // allocate a new file (structure) table entry for this file name
            iNum = filename.equals("/") ? 0 : dir.namei(filename);  //if root set 0, otherwise find inumber
            if (iNum >= 0){
                inode = new Inode(iNum);

                if (mode.equals("r"))   //request reading
                {
                    if (inode.flag == READ || inode.flag == EMPTY || inode.flag == USED)
                    {
                        inode.flag = READ;  //change flag and break
                        break;
                    }
                    else if (inode.flag == WRITE)
                    {
                        try {
                            wait();
                        } catch (InterruptedException e){
                            // throw exception
                        }
                    }

                    else    //request write, write/read, or append
                    {
                        if (inode.flag == EMPTY || inode.flag == USED) {
                            inode.flag = WRITE;
                            break;
                        } else {
                            try {
                                wait();
                            } catch (InterruptedException e) {
                            }
                        }
                    }
                }
                else if (!mode.equals("r")) //if node doesn't exist
                {
                    iNum = dir.ialloc(filename);
                    inode = new Inode(iNum);
                    inode.flag = WRITE;
                    break;
                }
                else {
                    return null;
                }
            }

            // allocate/retrieve and register the corresponding inode using dir
            // increment this inode's count
            // immediately write back this inode to the disk
            // return a reference to this file (structure) table entry
        }
        inode.count++;
        inode.toDisk(iNum);
        //create new fileTableEntry and add it to file table
        FileTableEntry entry = new FileTableEntry(inode, iNum, mode);
        table.addElement(entry);
        return entry;
    }

    public synchronized boolean ffree( FileTableEntry entry ) {
        // receive a file table entry reference
        Inode inode = new Inode(entry.iNumber);
        //try and remove FTE if it is in table, the remove will return true
        // return true if this file table entry found in my table
        if (table.remove(entry))
        {
            if (inode.flag == READ)
            {
                if (inode.count == 1)
                {
                    // free this file table entry.
                    notify();
                    inode.flag = USED;
                }
            }
            else if (inode.flag == WRITE)
            {
                inode.flag = USED;
                notifyAll();
            }
            //decrease the count of users of that file
            inode.count--;
            // save the corresponding inode to the disk
            inode.toDisk(entry.iNumber);
            return true;
        }
        return false;
    }

    public synchronized boolean fempty( ) {
        return table.isEmpty( );  // return if table is empty
    }                            // should be called before starting a format
}
